# import os

from geoip import geolite2

paths_toYoutube = [['127.0.0.1', '100.98.68.1', '10.201.234.1', '74.125.146.38', '172.217.2.78'],
                   ['127.0.0.1', '100.98.68.1', '10.201.234.1', '74.125.146.38', '108.170.253.1', '108.170.253.19',
                    '216.58.192.46'],
                   ['127.0.0.1', '100.98.68.1', '10.201.234.1', '74.125.146.38', '216.239.57.170', '172.217.2.142']]

paths_toTwitch = [['127.0.0.1', '10.201.232.57', '10.201.232.53', '10.201.232.38', '10.201.232.42', '10.201.232.61',
                  '10.201.232.5', '62.115.58.205', '0.0.0.0']]

filter_ip = ['192.168.100.1', '192.168.10.1', '192.168.1.1',
             '10.0.2.2', '192.168.0.1', '172.21.140.1', '192.168.4.1',
             '192.168.0.254', '192.168.10.1', '192.168.1.10']

count = len(paths_toYoutube)

for ippath in paths_toYoutube:
    print 'Path #:', count
    for ipaddress in ippath:
        match = geolite2.lookup(ipaddress)

        if match is None:
            if ipaddress in filter_ip:
                print '//////////////////////'
                print 'IP LAN: ', ipaddress
                print '//////////////////////'
                print
            else:
                if ipaddress == '127.0.0.1':
                    print '//////////////////////'
                    print 'IP START: ', ipaddress
                    print '//////////////////////'
                    print
                if ipaddress == '0.0.0.0':
                    print '//////////////////////'
                    print 'TARGET IP NEVER REACHED: ', ipaddress
                    print '//////////////////////'
                    print
                else:
                    print '//////////////////////'
                    print 'IP PRIVADA/ALLOCATED RANGE: ', ipaddress
                    print '//////////////////////'
                    print

        else:
            ipinfo = match.get_info_dict()
            print '//////////////////////'
            print 'IP:', match.ip
            print ipinfo
            print 'Ciudad: ', ipinfo['city']['names']['en']
            print 'State/Province: ', ipinfo['subdivisions'][0]['names']['en']
            print 'Pais:', ipinfo['country']['names']['en']
            print 'Continent:', ipinfo['continent']['names']['en']
            print '//////////////////////'
            print

    count -= 1
    print '++++++++++++++++++++++++++++'
